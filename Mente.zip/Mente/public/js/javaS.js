function diario(){
    window.location.href='../quiz/diario.php';
}
function vsTemp(){
    window.location.href='../quiz/vsTemp.php';
}
function comp(){
    window.location.href='../quiz/comp.php';
}
function casu(){
    window.location.href='../quiz/quiz.php';
}
function criacao(){
    window.location.href='../quiz/criar_quiz.php';
}
function gerQuiz(){
    window.location.href='../quiz/gerenciar_quiz.php';
}
function tema(){
    window.location.href='tema_user.php';
}
function criar(){
    window.location.href='criar_quiz_user.php';
}
function comun(){
    window.location.href='comun.php';
}