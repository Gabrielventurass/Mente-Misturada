<?php

declare(strict_types=1);

include 'menu.php';
