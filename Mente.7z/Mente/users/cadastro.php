<?php
    include "user.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link rel="shortcut icon" href="../img/cerebro.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
    <form action="cadastro.php" method="post">
    <center>
        <h1>Bem-vindo ao mundo Mente Misturada! Garanto que vai gostar!</h1>
    </center>
        <fieldset class="popUp">
            <legend>Faça seu cadastro</legend>

            <label for="nome" class="labels">Nome</label><br>
            <input type="text" name="nome" id="nome" class="inputs" required>
            <br>

            <label for="email" class="labels">E-mail</label><br>
            <input type="email" name="email" id="email" class="inputs" required>
            <br>

            <label for="senha" class="labels">Senha</label><br>
            <input type="password" name="senha" id="senha" class="inputs" required>
            <br>

            <input type="hidden" name="acao" value="salvar">

            <input type="submit" value="Cadastrar" class="btDf" style="margin-left: 100px;">

            <p>Já possui uma conta?<a href="login.php"> Clique aqui</a></p>
            <p>É administrador?<a href="../admin/login_adm.php"> Clique aqui</a></p>

            <?php
                if (isset($erroCadastro)) {
                    echo "<p style='color:red; text-align:center;'>" . htmlspecialchars($erroCadastro) . "</p>";
                }
?>
        </fieldset>
    </form>
</body>
</html>

