<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['email'])) {
    echo "Você precisa estar logado para criar ou editar um quiz.";
    exit;
}

$email = $_SESSION['email'];  // Obtemos o email do usuário logado

// Conectar ao banco de dados
try {
    $pdo = new PDO("mysql:host=localhost;dbname=mente", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se estamos editando um quiz
    $quiz_id = $_GET['quiz_id'] ?? null;
    $quiz_data = null;
    $perguntas_organizacao = []; // Inicializando a variável como um array vazio

    if ($quiz_id) {
        // Consultar os dados do quiz para edição
        $stmt = $pdo->prepare("SELECT * FROM quizzes_user WHERE id = :quiz_id AND usuario_email = :email");
        $stmt->execute(['quiz_id' => $quiz_id, 'email' => $email]);
        $quiz_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$quiz_data) {
            echo "Quiz não encontrado ou você não tem permissão para editar este quiz.";
            exit;
        }

        // Consultar as perguntas e alternativas associadas ao quiz
        $stmt_perguntas = $pdo->prepare("
            SELECT p.id AS pergunta_id, p.texto AS pergunta_texto, a.id AS alternativa_id, a.texto AS alternativa_texto, a.correta
            FROM perguntas_user p
            LEFT JOIN alternativas a ON p.id = a.pergunta_id
            WHERE p.quiz_id = :quiz_id
        ");
        $stmt_perguntas->execute(['quiz_id' => $quiz_id]);
        $perguntas_data = $stmt_perguntas->fetchAll(PDO::FETCH_ASSOC);

        // Organizar perguntas e alternativas em um formato fácil de usar no formulário
        foreach ($perguntas_data as $item) {
            $perguntas_organizacao[$item['pergunta_id']]['texto'] = $item['pergunta_texto'];
            $perguntas_organizacao[$item['pergunta_id']]['alternativas'][] = [
                'id' => $item['alternativa_id'],
                'texto' => $item['alternativa_texto'],
                'correta' => $item['correta']
            ];
        }
    }

} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
    exit;
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quiz_titulo = $_POST['titulo'] ?? null;
    $quiz_descricao = $_POST['descricao'] ?? null;
    $quiz_tema = $_POST['tema'] ?? null;
    $perguntas = $_POST['perguntas'] ?? [];

    // Validar os dados
    if (!$quiz_titulo || !$quiz_descricao || !$quiz_tema || empty($perguntas)) {
        echo "Por favor, preencha todos os campos e adicione perguntas.";
        exit;
    }

    try {
        // Inserir ou atualizar o quiz
        if ($quiz_id) {
            // Atualizar quiz existente
            $stmt = $pdo->prepare("
                UPDATE quizzes_user 
                SET titulo = :titulo, descricao = :descricao, tema = :tema
                WHERE id = :quiz_id
            ");
            $stmt->execute([
                'titulo' => $quiz_titulo,
                'descricao' => $quiz_descricao,
                'tema' => $quiz_tema,
                'quiz_id' => $quiz_id
            ]);
            $mensagem = "Quiz atualizado com sucesso!";
        } else {
            // Criar novo quiz
            $stmt = $pdo->prepare("
                INSERT INTO quizzes_user (titulo, descricao, tema, usuario_email)
                VALUES (:titulo, :descricao, :tema, :usuario_email)
            ");
            $stmt->execute([
                'titulo' => $quiz_titulo,
                'descricao' => $quiz_descricao,
                'tema' => $quiz_tema,
                'usuario_email' => $email
            ]);
            $quiz_id = $pdo->lastInsertId(); // Obter ID do quiz recém-criado
            $mensagem = "Quiz criado com sucesso!";
        }

        // Remover perguntas e alternativas antigas (caso esteja editando)
        if ($quiz_id) {
            $stmt = $pdo->prepare("DELETE FROM perguntas_user WHERE quiz_id = :quiz_id");
            $stmt->execute(['quiz_id' => $quiz_id]);

            $stmt = $pdo->prepare("DELETE FROM alternativas WHERE pergunta_id IN (SELECT id FROM perguntas_user WHERE quiz_id = :quiz_id)");
            $stmt->execute(['quiz_id' => $quiz_id]);
        }

        // Inserir as perguntas e alternativas
        foreach ($perguntas as $pergunta) {
            // Inserir pergunta no banco de dados
            $stmt = $pdo->prepare("
                INSERT INTO perguntas_user (quiz_id, texto)
                VALUES (:quiz_id, :texto)
            ");
            $stmt->execute([
                'quiz_id' => $quiz_id,
                'texto' => $pergunta['texto']
            ]);

            // Obter o ID da pergunta recém-criada
            $pergunta_id = $pdo->lastInsertId();

            // Inserir as alternativas para cada pergunta
            foreach ($pergunta['alternativas'] as $alt) {
                // Verificar se a chave 'correta' existe, caso contrário, atribuir '0'
                $correta = isset($alt['correta']) ? 1 : 0;

                // Inserir alternativa no banco de dados
                $stmt = $pdo->prepare("
                    INSERT INTO alternativas (pergunta_id, texto, correta)
                    VALUES (:pergunta_id, :texto, :correta)
                ");
                $stmt->execute([
                    'pergunta_id' => $pergunta_id,
                    'texto' => $alt['texto'],
                    'correta' => $correta  // Definir '1' para correta, '0' caso contrário
                ]);
            }
        }

    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Criar ou Editar Quiz</title>
</head>
<body>
    <br>
    <a href="meu_quiz.php"><img src="../img/seta.png" height="50px"></a>
    <h1><?php echo $quiz_id ? "Editar Quiz" : "Criar Novo Quiz"; ?></h1>

    <?php if (isset($mensagem)) { echo "<p style='color: green;'>$mensagem</p>"; } ?>

    <form method="POST">
        <label for="titulo">Título do Quiz:</label><br>
        <input type="text" name="titulo" value="<?php echo $quiz_data['titulo'] ?? ''; ?>" required><br><br>

        <label for="descricao">Descrição do Quiz:</label><br>
        <textarea name="descricao" required><?php echo $quiz_data['descricao'] ?? ''; ?></textarea><br><br>

        <label for="tema">Tema do Quiz:</label><br>
        <input type="text" name="tema" value="<?php echo $quiz_data['tema'] ?? ''; ?>" required><br><br>

        <h3>Adicionar Perguntas</h3>
        <div id="perguntas-container">
            <?php 
            $perguntaCount = 0;
            foreach ($perguntas_organizacao as $pergunta_id => $pergunta): 
            ?>
                <div class="pergunta">
                    <label for="pergunta_texto">Texto da Pergunta:</label><br>
                    <input type="text" name="perguntas[<?php echo $perguntaCount; ?>][texto]" value="<?php echo htmlspecialchars($pergunta['texto']); ?>" required><br><br>

                    <h4>Alternativas:</h4>
                    <?php foreach ($pergunta['alternativas'] as $altIndex => $alt): ?>
                        <label for="alt<?php echo $altIndex+1; ?>">Alternativa <?php echo $altIndex+1; ?>:</label><br>
                        <input type="text" name="perguntas[<?php echo $perguntaCount; ?>][alternativas][<?php echo $altIndex; ?>][texto]" value="<?php echo htmlspecialchars($alt['texto']); ?>" required><br>
                        <label for="alt<?php echo $altIndex+1; ?>_corret">Alternativa Correta?</label>
                        <input type="checkbox" name="perguntas[<?php echo $perguntaCount; ?>][alternativas][<?php echo $altIndex; ?>][correta]" value="1" <?php echo $alt['correta'] ? 'checked' : ''; ?>><br><br>
                    <?php endforeach; ?>
                </div>
            <?php 
            $perguntaCount++;
            endforeach; 
            ?>
        </div>

        <button type="submit"><?php echo $quiz_id ? "Atualizar Quiz" : "Criar Quiz"; ?></button>
    </form>
</body>
</html>
